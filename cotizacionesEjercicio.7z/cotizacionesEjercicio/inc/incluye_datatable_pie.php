<!--PARA DATATABLE>-->
        <script src = "js/jquery2.min.js" type="text/javascript"></script>
        <script src = "js/bootstrap.min.js" type="text/javascript"></script>
        <script src = "js/jquery.dataTables.min.js" type="text/javascript"></script>
        <script src = "js/dataTables.bootstrap.min.js" type="text/javascript"></script>
        <script src = "https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js" type="text/javascript"></script>
        <script type="text/javascript">
            var oTable;
            $(function () {
                oTable = $('#example').DataTable();
            });
        </script>

